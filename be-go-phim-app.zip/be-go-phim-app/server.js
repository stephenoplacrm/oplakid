'use strict';
/*
 * Bé Gõ Phím: máy chủ web.
 * - Tài khoản phụ huynh: đăng ký, đăng nhập, đăng xuất, quên mật khẩu, đổi mật khẩu, xoá tài khoản.
 * - Lưu hồ sơ bé và tiến độ học theo từng tài khoản (SQLite).
 * - WebSocket /ws: ai đang online, phòng đua với bạn.
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const { promisify } = require('util');
const express = require('express');
const { WebSocketServer } = require('ws');
const Database = require('better-sqlite3');

const scrypt = promisify(crypto.scrypt);

/* ---------------- Cấu hình ---------------- */
const PORT = Number(process.env.PORT) || 3000;
const APP_ORIGIN = (process.env.APP_ORIGIN || `http://localhost:${PORT}`).replace(/\/+$/, '');
const COOKIE_SECURE = process.env.COOKIE_SECURE ? process.env.COOKIE_SECURE === 'true' : APP_ORIGIN.startsWith('https://');
const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, 'data', 'be-go-phim.sqlite');
const SESSION_DAYS = 30;
const COOKIE = 'bgp_sid';
const MAX_DOC_BYTES = 250 * 1024;
const MAX_DOCS_PER_USER = 60;
const MAX_SOCKETS_PER_USER = 12;

/* ---------------- Cơ sở dữ liệu ---------------- */
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  pw TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  consent_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id);
CREATE TABLE IF NOT EXISTS resets(
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS docs(
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  data TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY(user_id, name)
);
`);

const q = {
  userByEmail: db.prepare('SELECT * FROM users WHERE email = ?'),
  userById: db.prepare('SELECT id, email, created_at FROM users WHERE id = ?'),
  userPwById: db.prepare('SELECT pw FROM users WHERE id = ?'),
  insertUser: db.prepare('INSERT INTO users(id, email, pw, created_at, consent_at) VALUES(?, ?, ?, ?, ?)'),
  updatePw: db.prepare('UPDATE users SET pw = ? WHERE id = ?'),
  deleteUser: db.prepare('DELETE FROM users WHERE id = ?'),
  insertSession: db.prepare('INSERT INTO sessions(token_hash, user_id, expires_at) VALUES(?, ?, ?)'),
  sessionUser: db.prepare('SELECT u.id, u.email FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?'),
  deleteSession: db.prepare('DELETE FROM sessions WHERE token_hash = ?'),
  deleteUserSessions: db.prepare('DELETE FROM sessions WHERE user_id = ?'),
  deleteOtherSessions: db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash <> ?'),
  purgeSessions: db.prepare('DELETE FROM sessions WHERE expires_at <= ?'),
  insertReset: db.prepare('INSERT INTO resets(token_hash, user_id, expires_at) VALUES(?, ?, ?)'),
  resetUser: db.prepare('SELECT user_id FROM resets WHERE token_hash = ? AND expires_at > ?'),
  deleteResets: db.prepare('DELETE FROM resets WHERE user_id = ?'),
  purgeResets: db.prepare('DELETE FROM resets WHERE expires_at <= ?'),
  getDoc: db.prepare('SELECT data, updated_at FROM docs WHERE user_id = ? AND name = ?'),
  countDocs: db.prepare('SELECT COUNT(*) AS n FROM docs WHERE user_id = ?'),
  upsertDoc: db.prepare(`INSERT INTO docs(user_id, name, data, updated_at) VALUES(?, ?, ?, ?)
    ON CONFLICT(user_id, name) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at`),
  deleteDoc: db.prepare('DELETE FROM docs WHERE user_id = ? AND name = ?')
};

/* ---------------- Tiện ích bảo mật ---------------- */
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');
const newToken = () => crypto.randomBytes(32).toString('base64url');
const SCRYPT = { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };

async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = await scrypt(pw, salt, 64, SCRYPT);
  return ['scrypt', SCRYPT.N, SCRYPT.r, SCRYPT.p, salt.toString('base64'), hash.toString('base64')].join('$');
}
async function verifyPassword(pw, stored) {
  const parts = String(stored).split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [, N, r, p, salt, hash] = parts;
  const expected = Buffer.from(hash, 'base64');
  const got = await scrypt(pw, Buffer.from(salt, 'base64'), expected.length, { N: +N, r: +r, p: +p, maxmem: SCRYPT.maxmem });
  return crypto.timingSafeEqual(expected, got);
}
let DUMMY_HASH = null;
hashPassword(crypto.randomBytes(12).toString('hex')).then(h => { DUMMY_HASH = h; });

function parseCookies(header) {
  const out = {};
  String(header || '').split(';').forEach(part => {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}
function userFromRequest(req) {
  const token = parseCookies(req.headers.cookie)[COOKIE];
  if (!token || token.length > 100) return null;
  const row = q.sessionUser.get(sha256(token), Date.now());
  return row ? { id: row.id, email: row.email, tokenHash: sha256(token) } : null;
}
function startSession(res, userId) {
  const token = newToken();
  const expires = Date.now() + SESSION_DAYS * 864e5;
  q.insertSession.run(sha256(token), userId, expires);
  res.setHeader('Set-Cookie', `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_DAYS * 86400}${COOKIE_SECURE ? '; Secure' : ''}`);
}
function clearCookie(res) {
  res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${COOKIE_SECURE ? '; Secure' : ''}`);
}

/* Giới hạn số lần thử (chống dò mật khẩu) */
const buckets = new Map();
function rateLimited(key, max, windowMs) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || b.reset <= now) { b = { n: 0, reset: now + windowMs }; buckets.set(key, b); }
  b.n += 1;
  return b.n > max;
}
setInterval(() => { const now = Date.now(); for (const [k, b] of buckets) if (b.reset <= now) buckets.delete(k); }, 60_000).unref();
setInterval(() => { const now = Date.now(); q.purgeSessions.run(now); q.purgeResets.run(now); }, 3_600_000).unref();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const normEmail = e => String(e || '').trim().toLowerCase();
const validEmail = e => e.length <= 254 && EMAIL_RE.test(e);
const validPassword = p => typeof p === 'string' && p.length >= 8 && p.length <= 128;

/* ---------------- Gửi email ---------------- */
let mailer = null;
if (process.env.SMTP_URL) {
  try { mailer = require('nodemailer').createTransport(process.env.SMTP_URL); }
  catch (e) { console.error('Không khởi tạo được SMTP:', e.message); }
}
async function sendResetEmail(to, link) {
  if (!mailer) {
    console.log(`[quên mật khẩu] Chưa cấu hình SMTP_URL. Link đặt lại cho ${to}: ${link}`);
    return;
  }
  await mailer.sendMail({
    from: process.env.MAIL_FROM || 'Bé Gõ Phím <no-reply@localhost>',
    to,
    subject: 'Đặt lại mật khẩu Bé Gõ Phím',
    text: `Chào bạn,\n\nBấm vào link dưới đây để đặt mật khẩu mới (link có hiệu lực trong 1 giờ):\n${link}\n\nNếu bạn không yêu cầu, hãy bỏ qua email này.\n\nBé Gõ Phím`
  });
}

/* ---------------- Ứng dụng web ---------------- */
const app = express();
app.disable('x-powered-by');
const TP = process.env.TRUST_PROXY;
app.set('trust proxy', !TP ? 'loopback' : /^\d+$/.test(TP) ? Number(TP) : TP === 'true' ? true : TP);

const wsOrigin = APP_ORIGIN.replace(/^http/, 'ws');
app.use((req, res, next) => {
  res.setHeader('Content-Security-Policy', [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data:",
    `connect-src 'self' ${wsOrigin}`,
    "frame-ancestors 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "object-src 'none'"
  ].join('; '));
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (COOKIE_SECURE) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
  next();
});

/* Chống CSRF: yêu cầu thay đổi dữ liệu phải đến từ chính trang web */
function sameOrigin(req) {
  const origin = req.headers.origin;
  if (origin) return origin === APP_ORIGIN;
  const site = req.headers['sec-fetch-site'];
  return !site || site === 'same-origin' || site === 'none';
}
app.use('/api', (req, res, next) => {
  if (req.method !== 'GET' && !sameOrigin(req)) return res.status(403).json({ error: 'Yêu cầu không hợp lệ.' });
  next();
});
app.use('/api', express.json({ limit: '300kb' }));

function requireUser(req, res, next) {
  const u = userFromRequest(req);
  if (!u) return res.status(401).json({ error: 'Bạn cần đăng nhập.' });
  req.user = u;
  next();
}
const ip = req => req.ip || 'unknown';
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

app.get('/api/auth/me', (req, res) => {
  const u = userFromRequest(req);
  if (!u) return res.status(401).json({ error: 'Chưa đăng nhập.' });
  res.json({ user: { id: u.id, email: u.email } });
});

app.post('/api/auth/register', wrap(async (req, res) => {
  const email = normEmail(req.body.email);
  const { password, consent } = req.body;
  if (rateLimited('reg:' + ip(req), 10, 3_600_000)) return res.status(429).json({ error: 'Bạn thử quá nhiều lần. Đợi một lát rồi thử lại.' });
  if (!validEmail(email)) return res.status(400).json({ error: 'Email chưa đúng định dạng.' });
  if (!validPassword(password)) return res.status(400).json({ error: 'Mật khẩu cần từ 8 đến 128 ký tự.' });
  if (consent !== true) return res.status(400).json({ error: 'Bạn cần xác nhận là cha mẹ hoặc người giám hộ và đồng ý với chính sách quyền riêng tư.' });
  if (q.userByEmail.get(email)) return res.status(409).json({ error: 'Email này đã có tài khoản. Bạn hãy đăng nhập, hoặc dùng “Quên mật khẩu”.' });
  const id = crypto.randomUUID();
  const now = Date.now();
  q.insertUser.run(id, email, await hashPassword(password), now, now);
  startSession(res, id);
  res.status(201).json({ user: { id, email } });
}));

app.post('/api/auth/login', wrap(async (req, res) => {
  const email = normEmail(req.body.email);
  const password = String(req.body.password || '');
  if (rateLimited('login:' + ip(req), 30, 900_000) || rateLimited('login:' + email, 10, 900_000)) {
    return res.status(429).json({ error: 'Bạn thử quá nhiều lần. Đợi 15 phút rồi thử lại.' });
  }
  const row = q.userByEmail.get(email);
  const ok = row ? await verifyPassword(password, row.pw) : (DUMMY_HASH && await verifyPassword(password, DUMMY_HASH), false);
  if (!ok) return res.status(401).json({ error: 'Email hoặc mật khẩu chưa đúng.' });
  startSession(res, row.id);
  res.json({ user: { id: row.id, email: row.email } });
}));

app.post('/api/auth/logout', (req, res) => {
  const u = userFromRequest(req);
  if (u) q.deleteSession.run(u.tokenHash);
  clearCookie(res);
  res.json({ ok: true });
});

app.post('/api/auth/forgot', wrap(async (req, res) => {
  const email = normEmail(req.body.email);
  if (rateLimited('forgot:' + ip(req), 10, 3_600_000) || rateLimited('forgot:' + email, 3, 3_600_000)) {
    return res.status(429).json({ error: 'Bạn yêu cầu quá nhiều lần. Đợi một lát rồi thử lại.' });
  }
  const row = validEmail(email) ? q.userByEmail.get(email) : null;
  if (row) {
    const token = newToken();
    q.insertReset.run(sha256(token), row.id, Date.now() + 3_600_000);
    try { await sendResetEmail(row.email, `${APP_ORIGIN}/?reset=${token}`); }
    catch (e) { console.error('Gửi email thất bại:', e.message); }
  }
  res.json({ ok: true });
}));

app.post('/api/auth/reset', wrap(async (req, res) => {
  const token = String(req.body.token || '');
  const { password } = req.body;
  if (rateLimited('reset:' + ip(req), 20, 3_600_000)) return res.status(429).json({ error: 'Bạn thử quá nhiều lần.' });
  if (!validPassword(password)) return res.status(400).json({ error: 'Mật khẩu cần từ 8 đến 128 ký tự.' });
  const row = token ? q.resetUser.get(sha256(token), Date.now()) : null;
  if (!row) return res.status(400).json({ error: 'Link đặt lại đã hết hạn hoặc đã dùng rồi. Bạn hãy yêu cầu link mới.' });
  q.updatePw.run(await hashPassword(password), row.user_id);
  q.deleteResets.run(row.user_id);
  q.deleteUserSessions.run(row.user_id);
  startSession(res, row.user_id);
  const u = q.userById.get(row.user_id);
  res.json({ user: { id: u.id, email: u.email } });
}));

app.post('/api/auth/password', requireUser, wrap(async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  if (rateLimited('pw:' + req.user.id, 10, 900_000)) return res.status(429).json({ error: 'Bạn thử quá nhiều lần.' });
  if (!validPassword(newPassword)) return res.status(400).json({ error: 'Mật khẩu mới cần từ 8 đến 128 ký tự.' });
  const row = q.userPwById.get(req.user.id);
  if (!row || !(await verifyPassword(String(oldPassword || ''), row.pw))) return res.status(401).json({ error: 'Mật khẩu hiện tại chưa đúng.' });
  q.updatePw.run(await hashPassword(newPassword), req.user.id);
  q.deleteOtherSessions.run(req.user.id, req.user.tokenHash);
  res.json({ ok: true });
}));

app.post('/api/account/delete', requireUser, wrap(async (req, res) => {
  if (rateLimited('del:' + req.user.id, 5, 900_000)) return res.status(429).json({ error: 'Bạn thử quá nhiều lần.' });
  const row = q.userPwById.get(req.user.id);
  if (!row || !(await verifyPassword(String(req.body.password || ''), row.pw))) return res.status(401).json({ error: 'Mật khẩu chưa đúng.' });
  q.deleteUser.run(req.user.id);
  disconnectUser(req.user.id);
  clearCookie(res);
  res.json({ ok: true });
}));

/* Kho dữ liệu riêng của từng tài khoản: danh sách hồ sơ bé và tiến độ từng bé */
const DOC_RE = /^(profiles|p-[a-z0-9]{4,32})$/;
app.get('/api/docs/:name', requireUser, (req, res) => {
  if (!DOC_RE.test(req.params.name)) return res.status(400).json({ error: 'Tên không hợp lệ.' });
  const row = q.getDoc.get(req.user.id, req.params.name);
  if (!row) return res.json({ exists: false });
  res.json({ exists: true, data: { json: row.data, updatedAt: row.updated_at } });
});
app.put('/api/docs/:name', requireUser, (req, res) => {
  const name = req.params.name;
  if (!DOC_RE.test(name)) return res.status(400).json({ error: 'Tên không hợp lệ.' });
  const { json, updatedAt } = req.body || {};
  if (typeof json !== 'string' || Buffer.byteLength(json) > MAX_DOC_BYTES) return res.status(413).json({ error: 'Dữ liệu quá lớn.' });
  try { JSON.parse(json); } catch { return res.status(400).json({ error: 'Dữ liệu không hợp lệ.' }); }
  if (!q.getDoc.get(req.user.id, name) && q.countDocs.get(req.user.id).n >= MAX_DOCS_PER_USER) {
    return res.status(409).json({ error: 'Tài khoản đã có quá nhiều hồ sơ.' });
  }
  q.upsertDoc.run(req.user.id, name, json, Number.isFinite(updatedAt) ? Math.floor(updatedAt) : Date.now());
  res.json({ ok: true });
});
app.delete('/api/docs/:name', requireUser, (req, res) => {
  if (!DOC_RE.test(req.params.name) || req.params.name === 'profiles') return res.status(400).json({ error: 'Tên không hợp lệ.' });
  q.deleteDoc.run(req.user.id, req.params.name);
  res.json({ ok: true });
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Không tìm thấy.' }));
app.use('/vendor/three.min.js', (req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  res.sendFile(require.resolve('three/build/three.min.js'));
});
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'], maxAge: '1h' }));
app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(err.status === 400 || err.type === 'entity.parse.failed' ? 400 : 500).json({ error: 'Có lỗi xảy ra, bạn thử lại nhé.' });
});

/* ---------------- WebSocket: ai đang online và phòng đua ---------------- */
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true, maxPayload: 8 * 1024 });
const peers = new Map(); // peerId -> { ws, userId, presence, updatedAt, tokens, last }

server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url, APP_ORIGIN);
  if (url.pathname !== '/ws' || req.headers.origin !== APP_ORIGIN) { socket.write('HTTP/1.1 403 Forbidden\r\n\r\n'); socket.destroy(); return; }
  const user = userFromRequest(req);
  if (!user) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); socket.destroy(); return; }
  let count = 0;
  for (const p of peers.values()) if (p.userId === user.id) count++;
  if (count >= MAX_SOCKETS_PER_USER) { socket.write('HTTP/1.1 429 Too Many Requests\r\n\r\n'); socket.destroy(); return; }
  wss.handleUpgrade(req, socket, head, ws => { ws.user = user; wss.emit('connection', ws); });
});

const AVATARS = new Set(['🐯', '🐰', '🐼', '🦊', '🐸']);
const STAGES = new Set(['bo', 'di', 'chay']);
const PHASES = new Set(['lobby', 'countdown', 'racing', 'done']);
const KINDS = new Set(['sent', 'long', 'words', 'home', 'keys']);
const WHERE = new Set(['home', 'play', 'game', 'results', 'parent', 'online', 'login', 'world', 'auth']);
const BAD_CHARS = /[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/g;
const num = (v, lo, hi) => (typeof v === 'number' && Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : undefined);

function cleanPatch(patch) {
  const out = {};
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) return out;
  for (const [k, v] of Object.entries(patch)) {
    if (v === null) { out[k] = null; continue; }
    switch (k) {
      case 'nick': if (typeof v === 'string') { const s = v.replace(BAD_CHARS, '').trim().slice(0, 12); if (s) out.nick = s; } break;
      case 'av': if (AVATARS.has(v)) out.av = v; break;
      case 'stage': if (STAGES.has(v)) out.stage = v; break;
      case 'where': if (WHERE.has(v)) out.where = v; break;
      case 'race': if (typeof v === 'string' && /^[a-z0-9]{5}$/.test(v)) out.race = v; break;
      case 'host': if (typeof v === 'boolean') out.host = v; break;
      case 'phase': if (PHASES.has(v)) out.phase = v; break;
      case 'kind': if (KINDS.has(v)) out.kind = v; break;
      case 'round': { const n = num(v, 0, 1e6); if (n !== undefined) out.round = Math.floor(n); break; }
      case 'prog': { const n = num(v, 0, 1); if (n !== undefined) out.prog = n; break; }
      case 'wpm': { const n = num(v, 0, 500); if (n !== undefined) out.wpm = Math.round(n); break; }
      case 'ms': { const n = num(v, 0, 3.6e6); if (n !== undefined) out.ms = Math.round(n); break; }
      case 'acc': { const n = num(v, 0, 100); if (n !== undefined) out.acc = Math.round(n); break; }
      case 'text': if (typeof v === 'string') out.text = v.replace(BAD_CHARS, '').slice(0, 400); break;
      default: break;
    }
  }
  return out;
}

/* Người lạ chỉ thấy con vật và khu của bạn khác. Biệt danh và mã phòng chỉ hiện
 * cho người cùng tài khoản phụ huynh hoặc cùng phòng đua. */
const RACE_KEYS = ['race', 'host', 'round', 'phase', 'kind', 'prog', 'wpm', 'ms', 'acc', 'text'];
function visiblePresence(p, viewer) {
  const pr = p.presence;
  if (p === viewer || p.userId === viewer.userId) return pr;
  const sameRace = pr.race && viewer.presence.race && pr.race === viewer.presence.race;
  const out = { av: pr.av, stage: pr.stage, where: pr.where };
  if (sameRace) { out.nick = pr.nick; for (const k of RACE_KEYS) if (pr[k] !== undefined) out[k] = pr[k]; }
  return out;
}

let broadcastTimer = null;
function scheduleBroadcast() {
  if (broadcastTimer) return;
  broadcastTimer = setTimeout(() => {
    broadcastTimer = null;
    const list = [...peers.entries()];
    for (const [id, viewer] of list) {
      if (viewer.ws.readyState !== 1) continue;
      const payload = list
        .filter(([, p]) => p.presence.stage)
        .map(([pid, p]) => ({ peer: pid, presence: visiblePresence(p, viewer), updatedAt: p.updatedAt }));
      viewer.ws.send(JSON.stringify({ t: 'peers', peers: payload }));
    }
  }, 60);
}
function disconnectUser(userId) {
  for (const p of peers.values()) if (p.userId === userId) p.ws.close(4001, 'account deleted');
}

wss.on('connection', ws => {
  const id = crypto.randomBytes(8).toString('hex');
  const peer = { ws, userId: ws.user.id, presence: {}, updatedAt: Date.now(), tokens: 40, last: Date.now() };
  peers.set(id, peer);
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.send(JSON.stringify({ t: 'hello', you: id }));
  scheduleBroadcast();
  ws.on('message', raw => {
    const now = Date.now();
    peer.tokens = Math.min(40, peer.tokens + (now - peer.last) / 1000 * 20);
    peer.last = now;
    if (peer.tokens < 1) return;
    peer.tokens -= 1;
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg && msg.t === 'presence') {
      const patch = cleanPatch(msg.patch);
      const next = { ...peer.presence };
      for (const [k, v] of Object.entries(patch)) { if (v === null) delete next[k]; else next[k] = v; }
      peer.presence = next;
      peer.updatedAt = now;
      scheduleBroadcast();
    }
  });
  ws.on('close', () => { peers.delete(id); scheduleBroadcast(); });
  ws.on('error', () => {});
});
setInterval(() => {
  for (const p of peers.values()) {
    if (!p.ws.isAlive) { p.ws.terminate(); continue; }
    p.ws.isAlive = false;
    p.ws.ping();
  }
}, 30_000).unref();

server.listen(PORT, () => {
  console.log(`Bé Gõ Phím đang chạy tại ${APP_ORIGIN} (cổng ${PORT})`);
  if (!mailer) console.log('Chưa cấu hình SMTP_URL: link “Quên mật khẩu” sẽ được in ra log thay vì gửi email.');
});
